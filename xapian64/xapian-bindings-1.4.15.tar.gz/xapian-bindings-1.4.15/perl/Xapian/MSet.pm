package Xapian::MSet;

1;
