package Xapian::ESet;

1;
