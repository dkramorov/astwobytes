package Xapian::DatabaseOpeningError;

=head1 NAME

Xapian::DatabaseOpeningError -  DatabaseOpeningError indicates failure to open a database.


=head1 DESCRIPTION


=cut
1;
