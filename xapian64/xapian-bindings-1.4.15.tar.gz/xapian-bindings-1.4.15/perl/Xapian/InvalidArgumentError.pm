package Xapian::InvalidArgumentError;

=head1 NAME

Xapian::InvalidArgumentError -  InvalidArgumentError indicates an invalid parameter value was passed to the API.

=head1 DESCRIPTION


=cut
1;
