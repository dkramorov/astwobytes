package Xapian::InternalError;

=head1 NAME

Xapian::InternalError -  InternalError indicates a runtime problem of some sort.


=head1 DESCRIPTION


=cut
1;
