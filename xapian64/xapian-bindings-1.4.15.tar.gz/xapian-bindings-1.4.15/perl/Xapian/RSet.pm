package Xapian::RSet;

1;
