package Xapian::UnimplementedError;

=head1 NAME

Xapian::UnimplementedError -  UnimplementedError indicates an attempt to use an unimplemented feature.


=head1 DESCRIPTION


=cut
1;
