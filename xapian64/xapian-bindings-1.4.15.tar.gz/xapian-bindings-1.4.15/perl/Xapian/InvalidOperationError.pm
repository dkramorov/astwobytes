package Xapian::InvalidOperationError;

=head1 NAME

Xapian::InvalidOperationError -  InvalidOperationError indicates the API was used in an invalid way.

=head1 DESCRIPTION


=cut
1;
