package Xapian::Stopper;

1;
