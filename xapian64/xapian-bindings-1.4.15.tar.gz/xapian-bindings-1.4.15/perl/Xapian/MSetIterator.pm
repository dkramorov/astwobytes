package Xapian::MSetIterator;

1;
