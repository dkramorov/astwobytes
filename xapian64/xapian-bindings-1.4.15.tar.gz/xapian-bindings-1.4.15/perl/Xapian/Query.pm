package Xapian::Query;

1;
