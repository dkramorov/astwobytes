package Xapian::PerlStopper;

1;
