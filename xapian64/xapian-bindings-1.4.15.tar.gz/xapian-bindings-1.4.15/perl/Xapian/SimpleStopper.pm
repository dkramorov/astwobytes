package Xapian::SimpleStopper;

1;
