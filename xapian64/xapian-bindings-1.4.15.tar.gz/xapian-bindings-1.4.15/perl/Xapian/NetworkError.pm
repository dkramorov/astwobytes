package Xapian::NetworkError;

=head1 NAME

Xapian::NetworkError -  Indicates a problem communicating with a remote database.


=head1 DESCRIPTION


=cut
1;
