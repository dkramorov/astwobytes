package Xapian::ESetIterator;

1;
