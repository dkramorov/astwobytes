package Xapian::QueryParserError;

=head1 NAME

Xapian::QueryParserError -  Indicates a query string can't be parsed.


=head1 DESCRIPTION


=cut
1;
