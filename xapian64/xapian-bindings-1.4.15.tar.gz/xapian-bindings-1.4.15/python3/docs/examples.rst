Examples
********

.. _simplesearch:

simplesearch.py
===============

.. literalinclude :: examples/simplesearch.py
   :language: python
   :emphasize-lines: 12,15-18
   :linenos:

.. _simpleindex:

simpleindex.py
==============

.. literalinclude :: examples/simpleindex.py
   :language: python
   :emphasize-lines: 12,15-18
   :linenos:

.. _simpleexpand:

simpleexpand.py
===============

.. literalinclude :: examples/simpleexpand.py
   :language: python
   :emphasize-lines: 12,15-18
   :linenos:

.. _simplematchdecider:


simplematchdecider.py
=====================

.. literalinclude :: examples/simplematchdecider.py
   :language: python
   :emphasize-lines: 12,15-18
   :linenos:
