xapian Package
==============

:mod:`xapian` Package
---------------------

.. automodule:: xapian
    :members:
    :undoc-members:
    :show-inheritance:
